export type TSortBy =
  'Name: A-Z' |
  'Name: Z-A' |
  'Price: Low to High' |
  'Price: High to Low';
